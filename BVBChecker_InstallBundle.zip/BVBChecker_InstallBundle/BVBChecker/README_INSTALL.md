
# BVBChecker Installationsbundle

Dieses Bundle enthält alles, was Sie für die Installation benötigen. **Platzhalter** sind in spitzen Klammern notiert und müssen angepasst/ersetzt werden.

## Inhalt
- `BVBChecker.exe.PLACEHOLDER` → **Ersetzen durch reale EXE** (siehe MAKE_EXE_INSTRUCTIONS.txt)
- `app\rules\rules.json` → Ihre Regelbasis (falls nicht vorhanden: `rules.json.PLACEHOLDER` nutzen)
- `app\rules\diagnoseliste_extracted.csv.PLACEHOLDER` → optionales CSV-Format
- `scripts\start_bvbchecker_json.bat`, `scripts\start_bvbchecker_csv.bat`
- `scripts\install.ps1` (Installation mit Optionen)
- `scripts\uninstall.ps1`
- `config\.env.example` → Konfigurations-**PLATZHALTER**
- `MAKE_EXE_INSTRUCTIONS.txt` → Bau der EXE aus dem Quellcode

## Schnellstart (ohne PowerShell-Skript)
1. Kopieren nach `<INSTALL_DIR>` (z. B. `C:\Program Files\BVBChecker\`).
2. **Ersetzen Sie `BVBChecker.exe.PLACEHOLDER` durch die echte `BVBChecker.exe`**.
3. Legen Sie Ihre Regeln ab:
   - JSON: `<INSTALL_DIR>\app\rules\rules.json`
   - oder CSV: `<INSTALL_DIR>\app\rules\diagnoseliste_extracted.csv`
4. Starten:
   - JSON: `<INSTALL_DIR>\scripts\start_bvbchecker_json.bat`
   - CSV: `<INSTALL_DIR>\scripts\start_bvbchecker_csv.bat`

## PowerShell-Installation (empfohlen, als Admin)
```powershell
cd "<BUNDLE_PATH>\BVBChecker\scripts"
.\install.ps1 -InstallDir "<INSTALL_DIR>" -KBVVersion "<KBV_VERSION>" -Mode "json" -CreateShortcut -RegisterAutostart
```
**Platzhalter:**
- `<BUNDLE_PATH>` → Pfad zu dem entpackten Bundle
- `<INSTALL_DIR>` → Zielordner, z. B. `C:\Program Files\BVBChecker`
- `<KBV_VERSION>` → z. B. `2025-01-01`

## Konfigurations-Varianten
- JSON-Modus: `RULES_FORMAT=json`, `RULES_JSON=<RULES_JSON_PATH>`
- CSV-Modus:  `RULES_FORMAT=csv`,  `RULES_CSV=<RULES_CSV_PATH>`

## Test
- Browser → `http://127.0.0.1:8000/health` sollte `{"status":"ok"}` zeigen.
- UI: `http://127.0.0.1:8000`

## Sicherheit/Whitelist
- Whitelist für `<INSTALL_DIR>\BVBChecker.exe` (unsigniert, Pfad/Hash in Applocker/Defender freigeben).

## Deinstallation
```powershell
cd "<BUNDLE_PATH>\BVBChecker\scripts"
.\uninstall.ps1 -InstallDir "<INSTALL_DIR>"
```

## Logik der Platzhalter
- `<INSTALL_DIR>`: Installationsziel (Standard `C:\Program Files\BVBChecker`).
- `<KBV_VERSION>`: Offizielle Versionsangabe der KBV-Diagnoseliste (z. B. `2025-01-01`).
- `<RULES_JSON_PATH>`: Pfad zur `rules.json`.
- `<RULES_CSV_PATH>`: Pfad zur `diagnoseliste_extracted.csv`.
```


param(
  [string]$InstallDir = "C:\Program Files\BVBChecker"
)
$ErrorActionPreference = "Stop"
Write-Host ">>> Entferne BVBChecker aus $InstallDir"
# Geplante Aufgabe entfernen (falls vorhanden)
try { Unregister-ScheduledTask -TaskName "BVBChecker Autostart" -Confirm:$false -ErrorAction SilentlyContinue } catch {}
# Dateien löschen
if (Test-Path $InstallDir) { Remove-Item -Recurse -Force "$InstallDir" }
Write-Host ">>> Deinstallation abgeschlossen."


<#  BVBChecker Installationsskript
    Verwendung (als Admin):
      PowerShell öffnen -> Rechtsklick "Als Administrator" ->
      cd <PFAD_ZUM_BUNDLE>\BVBChecker\scripts
      .\install.ps1 -InstallDir "C:\Program Files\BVBChecker" -KBVVersion "<KBV_VERSION>" -Mode "json" -CreateShortcut
#>
param(
  [string]$InstallDir = "C:\Program Files\BVBChecker",
  [string]$KBVVersion = "<KBV_VERSION>",     # PLACEHOLDER: z.B. 2025-01-01
  [ValidateSet("json","csv")] [string]$Mode = "json",
  [switch]$CreateShortcut,
  [switch]$RegisterAutostart
)

$ErrorActionPreference = "Stop"

Write-Host ">>> Installiere BVBChecker nach: $InstallDir"

# Ordner anlegen
New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
New-Item -ItemType Directory -Force -Path "$InstallDir\app\rules" | Out-Null

# Dateien kopieren
Copy-Item -Force "..\BVBChecker.exe.PLACEHOLDER" "$InstallDir\BVBChecker.exe.PLACEHOLDER"
if (Test-Path "..\..\BVBChecker.exe") {
  Copy-Item -Force "..\..\BVBChecker.exe" "$InstallDir\BVBChecker.exe"
}

# Regeln
if (Test-Path "..\app\rules\rules.json") {
  Copy-Item -Force "..\app\rules\rules.json" "$InstallDir\app\rules\rules.json"
}
if (Test-Path "..\app\rules\diagnoseliste_extracted.csv") {
  Copy-Item -Force "..\app\rules\diagnoseliste_extracted.csv" "$InstallDir\app\rules\diagnoseliste_extracted.csv"
}

# UI Assets (optional, falls EXE diese nicht enthält)
if (Test-Path "..\app\templates") {
  New-Item -ItemType Directory -Force -Path "$InstallDir\app\templates" | Out-Null
  Copy-Item -Recurse -Force "..\app\templates\*" "$InstallDir\app\templates\"
}
if (Test-Path "..\app\static") {
  New-Item -ItemType Directory -Force -Path "$InstallDir\app\static" | Out-Null
  Copy-Item -Recurse -Force "..\app\static\*" "$InstallDir\app\static\"
}

# Startskript kopieren
Copy-Item -Force "start_bvbchecker_json.bat" "$InstallDir\start_bvbchecker_json.bat"
Copy-Item -Force "start_bvbchecker_csv.bat" "$InstallDir\start_bvbchecker_csv.bat"

# Desktop-Verknüpfung optional
if ($CreateShortcut) {
  $Shell = New-Object -ComObject WScript.Shell
  $Desktop = [Environment]::GetFolderPath("Desktop")
  $Shortcut = $Shell.CreateShortcut("$Desktop\BVBChecker (Start).lnk")
  $Shortcut.TargetPath = "$InstallDir\start_bvbchecker_json.bat"
  $Shortcut.WorkingDirectory = "$InstallDir"
  $Shortcut.WindowStyle = 1
  $Shortcut.Description = "BVBChecker starten"
  $Shortcut.Save()
  Write-Host "Desktop-Verknüpfung erstellt."
}

# Autostart optional (geplanter Task beim Benutzer-Login)
if ($RegisterAutostart) {
  $action = New-ScheduledTaskAction -Execute "$InstallDir\start_bvbchecker_json.bat"
  $trigger = New-ScheduledTaskTrigger -AtLogOn
  $principal = New-ScheduledTaskPrincipal -UserId $env:UserName -LogonType InteractiveToken
  Register-ScheduledTask -TaskName "BVBChecker Autostart" -Action $action -Trigger $trigger -Principal $principal -Force | Out-Null
  Write-Host "Autostart als geplante Aufgabe registriert."
}

Write-Host ">>> Installation abgeschlossen."
Write-Host "Wichtig: Ersetze ggf. die Platzhalter-EXE durch die echte BVBChecker.exe."
Write-Host "Zum Start: '$InstallDir\start_bvbchecker_json.bat' ausführen."

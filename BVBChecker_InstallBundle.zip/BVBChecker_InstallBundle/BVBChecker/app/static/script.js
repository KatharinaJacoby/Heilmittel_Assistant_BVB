
async function postJSON(url, data) {
  const resp = await fetch(url, {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify(data)
  });
  if (!resp.ok) throw new Error(await resp.text());
  return await resp.json();
}
function parseICDs(text){
  return text.split(/[\s,;\n]+/).map(s=>s.trim()).filter(Boolean);
}
document.addEventListener("DOMContentLoaded", ()=>{
  const icd = document.getElementById("icdInput");
  const age = document.getElementById("age");
  const sex = document.getElementById("sex");
  const gruppe = document.getElementById("gruppe");
  const bereich = document.getElementById("bereich");
  const btn = document.getElementById("checkBtn");
  const out = document.getElementById("result");
  const status = document.getElementById("status");

  btn.addEventListener("click", async ()=>{
    status.textContent = "Checking…";
    status.className = "badge";
    out.textContent = "";
    try {
      const payload = {
        patient: {
          icd10_codes: parseICDs(icd.value),
          age: age.value ? parseInt(age.value) : null,
          sex: sex.value || "u",
          diagnosegruppe: gruppe.value || null,
          heilmittelbereich: bereich.value || null
        }
      };
      const res = await postJSON("/check", payload);
      const badge = res.eligible ? "ok" : "no";
      let msg = `Eligible: ${res.eligible ? "YES" : "NO"}\n`;
      if (res.kbv_version_date) msg += `KBV Version: ${res.kbv_version_date}\n`;
      if (res.matched && res.matched.length){
        msg += "\nMatched rules:\n";
        res.matched.forEach(m=>{
          msg += `- [${m.rule_id}] ${m.title}`;
          if (m.diagnosegruppe) msg += ` | Gruppe: ${m.diagnosegruppe}`;
          if (m.heilmittelbereich) msg += ` | Bereich: ${m.heilmittelbereich}`;
          msg += "\n";
        });
      }
      if (res.warnings && res.warnings.length){
        msg += "\nWarnings:\n" + res.warnings.map(w=>"- "+w).join("\n") + "\n";
      }
      if (res.missing_fields && res.missing_fields.length){
        msg += "\nMissing fields:\n" + res.missing_fields.map(m=>"- "+m).join("\n") + "\n";
      }
      out.textContent = msg;
      status.textContent = res.eligible ? "BVB möglich" : "Nicht BVB";
      status.className = "badge " + badge;
    } catch (e){
      status.textContent = "Error";
      status.className = "badge warn";
      out.textContent = "Error: " + e.message;
    }
  });

  // Drag and drop support
  const dz = icd;
  dz.addEventListener("dragover", (e)=>{ e.preventDefault(); dz.style.background="#f8fafc"; });
  dz.addEventListener("dragleave", ()=>{ dz.style.background=""; });
  dz.addEventListener("drop", async (e)=>{
    e.preventDefault();
    dz.style.background="";
    const file = e.dataTransfer.files[0];
    if (file){
      const text = await file.text();
      dz.value = (dz.value ? dz.value + "\n" : "") + text;
    }
  });
});


from typing import List, Optional, Literal
from pydantic import BaseModel, Field
from datetime import date

Sex = Literal["f", "m", "d", "u"]  # female, male, diverse, unknown

class PatientContext(BaseModel):
    icd10_codes: List[str] = Field(..., description="Primary ICD-10 codes (max 8 recommended)")
    second_icd10_codes: Optional[List[str]] = Field(default=None, description="Optional additional ICD-10 codes")
    age: Optional[int] = Field(default=None, ge=0, le=125)
    sex: Optional[Sex] = Field(default="u")
    diagnosegruppe: Optional[str] = None
    heilmittelbereich: Optional[str] = None  # PT/ET/LT/PO
    event_date: Optional[date] = None

class RuleRow(BaseModel):
    id: str
    title: str
    heilmittelbereich: Optional[str] = None
    diagnosegruppe: Optional[str] = None
    icd10_primary: List[str] = []
    icd10_secondary_any: List[str] = []
    requires_secondary_icd: bool = False
    age_min: Optional[int] = None
    age_max: Optional[int] = None
    months_since_event_max: Optional[int] = None
    notes: Optional[str] = None
    evidence: Optional[str] = None
    kbv_version_date: Optional[str] = None

class CheckRequest(BaseModel):
    patient: PatientContext

class MatchExplanation(BaseModel):
    rule_id: str
    title: str
    diagnosegruppe: Optional[str] = None
    heilmittelbereich: Optional[str] = None
    evidence: Optional[str] = None

class CheckResponse(BaseModel):
    eligible: bool
    matched: List[MatchExplanation]
    kbv_version_date: Optional[str] = None
    missing_fields: List[str] = []
    warnings: List[str] = []

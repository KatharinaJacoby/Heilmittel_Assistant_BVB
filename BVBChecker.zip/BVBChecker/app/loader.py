
from typing import List
import json
import csv
from pathlib import Path
from .models import RuleRow

def load_rules_json(path: str) -> List[RuleRow]:
    data = json.loads(Path(path).read_text(encoding='utf-8'))
    return [RuleRow(**row) for row in data]

def load_rules_csv(path: str, kbv_version_date: str = "") -> List[RuleRow]:
    rules = []
    with open(path, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f, delimiter=';')
        for i, row in enumerate(reader, start=1):
            rules.append(RuleRow(
                id=row.get("id") or f"KBV-BVB-{i:04d}",
                title=row.get("title") or row.get("diagnose_text") or "Unbenannt",
                heilmittelbereich=row.get("heilmittelbereich") or row.get("bereich"),
                diagnosegruppe=row.get("diagnosegruppe") or row.get("gruppe"),
                icd10_primary=[p.strip() for p in (row.get("icd10_primary") or row.get("icd") or "").split(',') if p.strip()],
                icd10_secondary_any=[p.strip() for p in (row.get("icd10_secondary_any") or row.get("icd2") or "").split(',') if p.strip()],
                requires_secondary_icd=(row.get("requires_secondary_icd") or row.get("zweit_icd_erforderlich") or "").strip().lower() in ("1","true","ja","yes","y"),
                age_min=int(row["age_min"]) if row.get("age_min") else None,
                age_max=int(row["age_max"]) if row.get("age_max") else None,
                months_since_event_max=int(row["months_since_event_max"]) if row.get("months_since_event_max") else None,
                notes=row.get("notes"),
                evidence=row.get("evidence"),
                kbv_version_date=row.get("kbv_version_date") or kbv_version_date
            ))
    return rules

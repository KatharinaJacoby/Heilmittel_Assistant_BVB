
import os
from fastapi import FastAPI, Request, UploadFile, Form
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from pydantic import ValidationError
from typing import List, Optional
from .models import PatientContext, CheckResponse
from .loader import load_rules_json, load_rules_csv
from .engine import evaluate_patient

APP_TITLE = "BVBChecker"
BASE_DIR = os.path.dirname(__file__)
RULES_JSON = os.getenv("RULES_JSON", os.path.join(BASE_DIR, "rules", "rules.json"))
RULES_CSV = os.getenv("RULES_CSV", os.path.join(BASE_DIR, "rules", "diagnoseliste_example.csv"))
RULES_FORMAT = os.getenv("RULES_FORMAT", "json")  # json or csv
KBV_VERSION = os.getenv("KBV_VERSION", "2025-01-01")

app = FastAPI(title=APP_TITLE)
app.mount("/static", StaticFiles(directory=os.path.join(BASE_DIR, "static")), name="static")
templates = Jinja2Templates(directory=os.path.join(BASE_DIR, "templates"))

def _load_rules():
    if RULES_FORMAT.lower() == "csv":
        return load_rules_csv(RULES_CSV, kbv_version_date=KBV_VERSION)
    return load_rules_json(RULES_JSON)

@app.get("/health")
def health():
    return {"status": "ok", "app": APP_TITLE}

@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request, "app_title": APP_TITLE})

@app.post("/check", response_model=CheckResponse)
async def check(patient: PatientContext):
    rules = _load_rules()
    eligible, matched, missing, warnings, kbv_version = evaluate_patient(patient, rules)
    return CheckResponse(
        eligible=eligible,
        matched=matched,
        kbv_version_date=kbv_version,
        missing_fields=missing,
        warnings=warnings
    )

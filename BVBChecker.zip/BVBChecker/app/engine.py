
import re
from datetime import date
from typing import List, Tuple, Dict, Any
from .models import RuleRow, PatientContext, MatchExplanation

def _normalize_code(code: str) -> str:
    return code.strip().upper().replace(" ", "")

def _match_any(code_list: List[str], patterns: List[str]) -> bool:
    norm = [_normalize_code(c) for c in code_list or []]
    for pat in patterns or []:
        # glob-to-regex: '*' -> '.*', '?' -> '.'
        rx = '^' + (pat.upper().replace('.', r'\.').replace('*', '.*').replace('?', '.')) + '$'
        cre = re.compile(rx)
        if any(cre.match(c) for c in norm):
            return True
    return False

def months_between(start: date, end: date) -> int:
    return (end.year - start.year) * 12 + (end.month - start.month)

def evaluate_patient(patient: PatientContext, rules: List[RuleRow]) -> Tuple[bool, List[MatchExplanation], List[str], List[str], str]:
    missing = []
    warnings = []
    matched: List[MatchExplanation] = []
    kbv_version_date = None

    if not patient.icd10_codes:
        missing.append("icd10_codes")

    for r in rules:
        if r.kbv_version_date:
            kbv_version_date = r.kbv_version_date
        if r.heilmittelbereich and patient.heilmittelbereich and r.heilmittelbereich != patient.heilmittelbereich:
            continue
        if r.diagnosegruppe and patient.diagnosegruppe and r.diagnosegruppe != patient.diagnosegruppe:
            continue
        if not _match_any(patient.icd10_codes, r.icd10_primary):
            continue
        if r.requires_secondary_icd:
            if not _match_any((patient.second_icd10_codes or patient.icd10_codes), r.icd10_secondary_any):
                warnings.append(f"Rule {r.id} requires a second ICD-10 code.")
                continue
        if r.age_min is not None and (patient.age is None or patient.age < r.age_min):
            continue
        if r.age_max is not None and (patient.age is None or patient.age > r.age_max):
            continue
        if r.months_since_event_max is not None:
            if patient.event_date is None:
                warnings.append(f"Rule {r.id} limited by event_date, but none provided.")
                continue
            if months_between(patient.event_date, date.today()) > r.months_since_event_max:
                continue

        matched.append(MatchExplanation(
            rule_id=r.id,
            title=r.title,
            diagnosegruppe=r.diagnosegruppe,
            heilmittelbereich=r.heilmittelbereich,
            evidence=r.evidence
        ))

    return (len(matched) > 0, matched, missing, warnings, kbv_version_date or "")

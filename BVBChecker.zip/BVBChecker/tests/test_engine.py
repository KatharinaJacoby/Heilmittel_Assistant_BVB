
from app.models import PatientContext
from app.loader import load_rules_json
from app.engine import evaluate_patient

def test_double_icd_rule():
    rules = load_rules_json("app/rules/rules.json")
    p = PatientContext(icd10_codes=["G81.1"], second_icd10_codes=["I69.3"], diagnosegruppe="EX3", heilmittelbereich="PT")
    eligible, matched, missing, warnings, _ = evaluate_patient(p, rules)
    assert eligible
    assert any(m.rule_id == "KBV-BVB-PT-0001" for m in matched)

def test_missing_second_icd():
    rules = load_rules_json("app/rules/rules.json")
    p = PatientContext(icd10_codes=["G81.1"], diagnosegruppe="EX3", heilmittelbereich="PT")
    eligible, matched, missing, warnings, _ = evaluate_patient(p, rules)
    assert not eligible
    assert any("requires a second ICD-10" in w for w in warnings)

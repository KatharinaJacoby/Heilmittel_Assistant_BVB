
# BVBChecker (Local REST + UI)

- Local-only FastAPI service on `http://127.0.0.1:8000`
- Drag/drop or paste ICD-10; optional age/sex; optional diagnosegruppe/heilmittelbereich.
- Returns JSON and a plain UI.

## Run (dev)
```bat
python -m venv .venv
.venv\Scripts\pip install -r requirements.txt
.venv\Scripts\python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Open: http://127.0.0.1:8000

## Configure rules
- Default uses `app/rules/rules.json`
- To use CSV: set env `RULES_FORMAT=csv` and `RULES_CSV=app\rules\diagnoseliste_example.csv`
- Set `KBV_VERSION=YYYY-MM-DD` to display version in results.

## PyInstaller (single EXE)
```bat
pip install pyinstaller
pyinstaller --noconfirm --onefile --add-data "app\templates;app/templates" --add-data "app\static;app/static" --add-data "app\rules;app/rules" -n BVBChecker.exe run_server.py
```

Then deploy `dist\BVBChecker.exe` to `C:\Program Files\BVBChecker\`.

## Windows service (optional)
Use NSSM or SC to run the EXE at startup, or a desktop shortcut.
```

